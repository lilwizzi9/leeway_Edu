const express = require('express');

const bodyParser = require('body-parser');

const Web3 = require("web3")

const app = express();

const port = 3000;

const projectID = 'c0e577fcf948437a81d317323c46bb9a';

const contractAddress = '0xF36495D4b287eA1BD5F25f74FFBA19bd8114E084';

//const web3 = new Web3(new Web3.providers.HttpProvider("https://ropsten.infura.io/v3/"+projectID+""));
const web3 = new Web3(new Web3.providers.HttpProvider("https://data-seed-prebsc-2-s2.binance.org:8545"));

const securitytoken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9webc11126';

app.use(bodyParser.json());

app.listen(port, () => {

  console.log('NODE IS RUNNING ON '+port+'');

});


app.all('/*', function (req, res, next) { // CORS headers

  res.header('Access-Control-Allow-Origin', '*'); // restrict it to the required domain

  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');

  // Set custom headers for CORS

  res.header('Access-Control-Allow-Headers', 'Content-type,Accept,X-Access-Token,X-Key');

  if (req.method === 'OPTIONS') {

    res.status(200).end()

  } else {

    next()

  }

});

/** API TO GET ETH BALANCE **/

app.get('/node/getETHbalance/:securitytoken/:address', (req, res) => {


  if (typeof window.ethereum !== 'undefined') {
    res.send({ data: 'MetaMask is installed!' });
  // console.log('MetaMask is installed!');
}

// if (typeof window.ethereum !== 'undefined') {
//         res.send({ data: 'web3 is enabled!' });
//         if(!firstCall) document.location.reload()
//     } else {
//       res.send({ data: 'no states!' });
//         // add a delay here as you want
//         checkWeb3ProviderRecursively(false)
//     }

  // if (typeof web3 !== 'undefined') {
  //   console.log('web3 is enabled');
  //  // res.send({ data: 'web3 is enabled!' });
  //   if (web3.currentProvider.isMetaMask === true) {
  //     console.log('MetaMask is active');
  //     res.send({ data: 'MetaMask is active' });
  //   } else {
  //     console.log('MetaMask is not available');
  //     res.send({ data: 'MetaMask is not available' });
  //   }
  // } else {
  //   console.log('web3 is not found');
  //   res.send({ data: 'web3 is not found' });
  // }


//   var address = req.params.address;

//   var api_security_token = req.params.securitytoken;

//   if(api_security_token != securitytoken)

//   {

//     res.send({ data: 'Token Mismatch!' });

//   }


// const account = web3.eth.accounts.privateKeyToAccount("c0e577fcf948437a81d317323c46bb9a")


//   web3.eth.getBalance(address, 

//     function(err, result) {

//       if (err) {

//         res.send({ data: err });

//       } else {

//         var ETHbalance = web3.fromWei(result);

//         res.send({ data: result });

//       }

//     })

});



/** API TO GET ETH BALANCE **/

/** GET TOKEN BALACE **/

app.get('/node/getTokenbalance/:securitytoken/:address', (req, res) => {

  var address = req.params.address;

  var api_security_token = req.params.securitytoken;

  if(api_security_token != securitytoken)

  {
    res.send({ data: 'Token Mismatch!' });

  }

  var minABI = [

  {

    "constant":true,

    "inputs":[{"name":"_owner","type":"address"}],

    "name":"balanceOf",

    "outputs":[{"name":"balance","type":"uint256"}],

    "type":"function"

  },

  {

    "constant":true,

    "inputs":[],

    "name":"decimals",

    "outputs":[{"name":"","type":"uint18"}],

    "type":"function"

  }

  ];


  var tokenInst = new web3.eth.contract(minABI,contractAddress);

  tokenInst.methods.balanceOf(address).call().then(function (bal) {

    res.send({ data: bal });

  });

});



/** GET TOKEN BALACE **/





/** TRANSFER TOKENS **/

app.get('/node/transferToken/:securitytoken/:toaddress', (req, res) => {



  var address = req.params.toaddress;

  var caddress = '0x48624c099c502E6D668b6e1B1Fb68D82198c9f4A';



  var abi = [

  {

    "constant":true,

    "inputs":[{"name":"_owner","type":"address"}],

    "name":"balanceOf",

    "outputs":[{"name":"balance","type":"uint256"}],

    "type":"function"

  },

  {

    "constant":true,

    "inputs":[],

    "name":"decimals",

    "outputs":[{"name":"","type":"uint18"}],

    "type":"function"

  }

  ];



  var account = contractAddress;

  var privateKey = "b7b9645f7ca508d61b3613a1910df03c2c337c039caf1a52b201881962b84c81";







  web3.eth.getTransactionCount(account, function (err, nonce) {

    var data = new web3.eth.Contract([

    {

      "constant": false,

      "inputs": [

      {

        "name": "_fName",

        "type": "string"

      },

      {

        "name": "_age",

        "type": "uint256"

      }

      ],

      "name": "setInstructor",

      "outputs": [],

      "payable": false,

      "stateMutability": "nonpayable",

      "type": "function"

    },

    {

      "constant": true,

      "inputs": [],

      "name": "getInstructor",

      "outputs": [

      {

        "name": "",

        "type": "string"

      },

      {

        "name": "",

        "type": "uint256"

      }

      ],

      "payable": false,

      "stateMutability": "view",

      "type": "function"

    }

    ],contractAddress);



    var gasPrice = web3.eth.gasPrice



    var rawTx = {

      nonce: nonce,

      gasPrice: web3.utils.toHex(gasPrice),

      gasLimit: 100000,

      to: caddress,

      value: 0,

      data: data,

    };



    var tx = new Tx(rawTx);

    var privateKeyBuff = new Buffer(privateKey, 'hex');;

    tx.sign(privateKeyBuff);



    var raw = '0x' + tx.serialize().toString('hex');

    web3.eth.sendRawTransaction(raw, function (err, transactionHash) {

      res.send({ data: err });

    });

  });



  // var minABI = [

  // {

  //  "constant":true,

  //  "inputs":[{"name":"_owner","type":"address"}],

  //  "name":"balanceOf",

  //  "outputs":[{"name":"balance","type":"uint256"}],

  //  "type":"function"

  // },

  // {

  //  "constant":true,

  //  "inputs":[],

  //  "name":"decimals",

  //  "outputs":[{"name":"","type":"uint18"}],

  //  "type":"function"

  // }

  // ];



 //  var value = web3.utils.toBN(10);



  // var myContract = new web3.eth.Contract(minABI, contractAddress);



  // var data = myContract.methods.transfer(address, value).encodeABI();





  // var rawTx = {

  //  "nonce": web3.utils.toHex(nonce),

  //  "gasPrice": "0x3b9aca00",

  //  "gasLimit": web3.utils.toHex(gasLimit),

  //  "to": contractAddress,

  //  "value": "0x00",

  //  "data": data,

  // }

  // const tx = new Tx(rawTx)

  // tx.sign('b7b9645f7ca508d61b3613a1910df03c2c337c039caf1a52b201881962b84c81');

  // let serializedTx = "0x" + tx.serialize().toString('hex');

  // web3.eth.sendSignedTransaction(serializedTx).on('transactionHash', function (txHash) {



  // }).on('receipt', function (receipt) {



  //  res.send({ data: receipt });

  //  console.log("receipt:" + receipt);

  // }).on('confirmation', function (confirmationNumber, receipt) {

 //    //console.log("confirmationNumber:" + confirmationNumber + " receipt:" + receipt);

 //  }).on('error', function (error) {

 //      res.send({ data: 'ERROR' });

 //  });





});

/** TRANSFER TOKENS **/







